import os
from pprint import pprint
from dataikuscoring import load_model


path_to_export = os.path.dirname(os.path.realpath(__file__))

# Load the model from current export path
model = load_model(path_to_export)

# The model provides a simple api similar to scikit-learn with:
# * model.predict to get scoring for a given input data
# * model.predict_proba to get probabilities in case of classification
#
# The accepted format for input data can be either:
# * pandas.DataFrame
# * List of dictionnaries
# * 2D numpy array
# * List of List
#
# The first dimension corresponds to observations
data_to_score = [
    {
        "fiscal_year_week": "2022_03"
        ,"fscl_wk_end_dt": "2021-10-23"
        ,"era": "Ramp up"
        ,"fiscalmonth": 1
        ,"fiscalmonth_5": False
        ,"fiscalweek": 3
        ,"offer_urgency_flag": False
        ,"offer_changeover_flag": False
        ,"offer_shadowside_flag": False
        ,"live_resorts_count": 1
        ,"direct_live_product_price_per_point": 188.0
        ,"live_150_incentive_amount_min": 0.05472636815920398
        ,"live_150_incentive_amount_max": 0.05472636815920398
        ,"guide_grace_preperf_count": 0
        ,"count_headcount_Guide_training_init": 1
        ,"days_worked_cruise_pct": 0.04658
        ,"labor_hours_guide_avg": 33
        ,"rofr_number_of_contracts_purchased_by_dvc": 36
        ,"rofr_number_of_contracts_refused_by_dvc": 89
        ,"third_party_resale_price_per_point_avg": 154
        ,"price_increase_flag": False
        ,"member_calls_outbound_guide": 785
        ,"member_calls_per_guide": 34.130434782608695
        ,"member_calls_outbound_dvca": 41
        ,"flash_sale_products_available": 4
        ,"flash_sale_products_new": 0
        ,"flash_sale_products_live_new": 0
        ,"net_contracts_total": 73.0
        ,"net_contracts_onsite": 14.0
        ,"net_contracts_virtual": 59.0
        ,"unique_members_contacted_sales": 1428.0
        ,"unique_members_contacted_marketing": 50.0
        ,"onsite_tours_lag_1_week": 105
        ,"onsite_tours_lag_2_weeks": 104
        ,"onsite_tours_lag_4_weeks": 0
        ,"virtual_tours_lag1": 120
        ,"2wks_before_price_increase": False
        ,"member_calls_outbound_Guide_lag_1_week": 801
        ,"member_calls_outbound_Guide_lag_2_weeks": 613
        ,"pct_members_any_banking_within_1_year_of_arrival": 0.33515731874145005
        ,"pct_members_any_borrow_within_1_year_of_arrival": 0.2968536251709986
        ,"pct_members_any_borrow_1_to_2_years_before_arrival": 0.2646081688489349
        ,"pct_members_any_borrow_2_to_3_years_before_arrival": 0.2667578659370725
        ,"pct_members_any_borrow_3_to_4_years_before_arrival": 0.2479968731678718
        ,"pct_members_any_borrow_4_to_5_years_before_arrival": 0.23373070158295878
        ,"pct_members_borrowed_multiple_years_in_past_5_years": 0.40981043580222787
        ,"new_product_month_after_launch": 0
        ,"new_product_on_sale_week": 0
        ,"pct_members_here_lagged_2_to_4_using_cash_avg": 0.027656927192401884
        ,"pct_members_here_lagged_13_to_17_using_cash_avg": 0.021897800453682552
        ,"loans_with_5.01_to_10_years_remaining_count": 34977
        ,"intent_to_buy_home": 6.9
        ,"app_target_addon": 118.22352
        ,"marketing_facebook_ads_groupID_count": 306
        ,"any_bk_1_time_use_points": 0
        ,"arv_1_time_use_points_count": 0
        ,"bk_3_bed_pct": 0.025597269624573378
        ,"bk_2_bed_pct": 0.16390784982935153
        ,"bk_1_bed_pct": 0.19505119453924916
        ,"avg_pct_previous_5_bookings_above_this_booking": 0.26468494749124855
        ,"avg_pct_previous_5_bookings_same_level": 0.4639926098794243
        ,"weekly_bookings": 8705
        ,"predict_set_flag": "Train"
        ,"consumer_confidence_interval_lag_1_week": 111.6
        ,"consumer_confidence_interval_lag_2_weeks": 111.6
        ,"consumer_confidence_interval_lag_4_weeks": 0
    }
    ,{
        "fiscal_year_week": "2022_04"
        ,"fscl_wk_end_dt": "2021-10-30"
        ,"era": "Ramp up"
        ,"fiscalmonth": 1
        ,"fiscalmonth_5": False
        ,"fiscalweek": 4
        ,"offer_urgency_flag": False
        ,"offer_changeover_flag": False
        ,"offer_shadowside_flag": False
        ,"live_resorts_count": 1
        ,"direct_live_product_price_per_point": 188.0
        ,"live_150_incentive_amount_min": 0.05472636815920398
        ,"live_150_incentive_amount_max": 0.05472636815920398
        ,"guide_grace_preperf_count": 0
        ,"count_headcount_Guide_training_init": 1
        ,"days_worked_cruise_pct": 0.04086
        ,"labor_hours_guide_avg": 30
        ,"rofr_number_of_contracts_purchased_by_dvc": 17
        ,"rofr_number_of_contracts_refused_by_dvc": 77
        ,"third_party_resale_price_per_point_avg": 151
        ,"price_increase_flag": False
        ,"member_calls_outbound_guide": 761
        ,"member_calls_per_guide": 33.08695652173913
        ,"member_calls_outbound_dvca": 28
        ,"flash_sale_products_available": 4
        ,"flash_sale_products_new": 0
        ,"flash_sale_products_live_new": 0
        ,"net_contracts_total": 79.0
        ,"net_contracts_onsite": 19.0
        ,"net_contracts_virtual": 60.0
        ,"unique_members_contacted_sales": 1406.0
        ,"unique_members_contacted_marketing": 37.0
        ,"onsite_tours_lag_1_week": 132
        ,"onsite_tours_lag_2_weeks": 105
        ,"onsite_tours_lag_4_weeks": 0
        ,"virtual_tours_lag1": 120
        ,"2wks_before_price_increase": False
        ,"member_calls_outbound_Guide_lag_1_week": 785
        ,"member_calls_outbound_Guide_lag_2_weeks": 801
        ,"pct_members_any_banking_within_1_year_of_arrival": 0.32970081236378046
        ,"pct_members_any_borrow_within_1_year_of_arrival": 0.30612244897959184
        ,"pct_members_any_borrow_1_to_2_years_before_arrival": 0.2593619972260749
        ,"pct_members_any_borrow_2_to_3_years_before_arrival": 0.26629680998613037
        ,"pct_members_any_borrow_3_to_4_years_before_arrival": 0.24549237170596394
        ,"pct_members_any_borrow_4_to_5_years_before_arrival": 0.231622746185853
        ,"pct_members_borrowed_multiple_years_in_past_5_years": 0.397463839904894
        ,"new_product_month_after_launch": 0
        ,"new_product_on_sale_week": 0
        ,"pct_members_here_lagged_2_to_4_using_cash_avg": 0.027421495715095983
        ,"pct_members_here_lagged_13_to_17_using_cash_avg": 0.02216310480617801
        ,"loans_with_5.01_to_10_years_remaining_count": 34865
        ,"intent_to_buy_home": 6.9
        ,"app_target_addon": 157.75871
        ,"marketing_facebook_ads_groupID_count": 221
        ,"any_bk_1_time_use_points": 0
        ,"arv_1_time_use_points_count": 0
        ,"bk_3_bed_pct": 0.029726812256082372
        ,"bk_2_bed_pct": 0.16939300838661464
        ,"bk_1_bed_pct": 0.1909823133770655
        ,"avg_pct_previous_5_bookings_above_this_booking": 0.2631087379353371
        ,"avg_pct_previous_5_bookings_same_level": 0.4714796873279753
        ,"weekly_bookings": 9215
        ,"predict_set_flag": "Train"
        ,"consumer_confidence_interval_lag_1_week": 111.6
        ,"consumer_confidence_interval_lag_2_weeks": 111.6
        ,"consumer_confidence_interval_lag_4_weeks": 0
    }
]


# For instance the following will output a numpy array containing the predictions for each
# observation

predict_result = model.predict(data_to_score)
print(" \nOutput of model.predict()\n")
pprint(predict_result)
