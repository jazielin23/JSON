import os
from pprint import pprint
from dataikuscoring import load_model


path_to_export = os.path.dirname(os.path.realpath(__file__))

# Load the model from current export path
model = load_model(path_to_export)

# The model provides a simple api similar to scikit-learn with:
# * model.predict to get scoring for a given input data
# * model.predict_proba to get probabilities in case of classification
#
# The accepted format for input data can be either:
# * pandas.DataFrame
# * List of dictionnaries
# * 2D numpy array
# * List of List
#
# The first dimension corresponds to observations
data_to_score = [
    {
        "weekending": "2017-10-21T00:00:00.000Z"
        ,"All_DVCACast": 127
        ,"pct_DVCA_Resorts": 16.535433070866144
        ,"avg_laborhours_dvca": 36.75
        ,"Operational_Guest_Value_Incentive": "None"
        ,"Operational_Guest_Mod_Incentive": "None"
        ,"Operational_Guest_DeluxeVilla_Incentive": "None"
        ,"Overall_Parks_TopGate": 5
        ,"Overall_Resorts_TopGate": 5
        ,"ERA_And_OfferFlag": "ERA_PreCovid_Normal_Offer_week"
        ,"dvcaparks_cast_perctogoal_median_tour": 0.8
        ,"dvcaresorts_cast_perctogoal_median_tour": 1.0
    }
    ,{
        "weekending": "2017-10-28T00:00:00.000Z"
        ,"All_DVCACast": 128
        ,"pct_DVCA_Resorts": 16.40625
        ,"avg_laborhours_dvca": 35.24
        ,"Operational_Guest_Value_Incentive": "None"
        ,"Operational_Guest_Mod_Incentive": "None"
        ,"Operational_Guest_DeluxeVilla_Incentive": "None"
        ,"Overall_Parks_TopGate": 5
        ,"Overall_Resorts_TopGate": 5
        ,"ERA_And_OfferFlag": "ERA_PreCovid_Normal_Offer_week"
        ,"dvcaparks_cast_perctogoal_median_tour": 0.8
        ,"dvcaresorts_cast_perctogoal_median_tour": 1.0
    }
]


# For instance the following will output a numpy array containing the predictions for each
# observation

predict_result = model.predict(data_to_score)
print(" \nOutput of model.predict()\n")
pprint(predict_result)
