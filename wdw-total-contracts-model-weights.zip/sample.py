import os
from pprint import pprint
from dataikuscoring import load_model


path_to_export = os.path.dirname(os.path.realpath(__file__))

# Load the model from current export path
model = load_model(path_to_export)

# The model provides a simple api similar to scikit-learn with:
# * model.predict to get scoring for a given input data
# * model.predict_proba to get probabilities in case of classification
#
# The accepted format for input data can be either:
# * pandas.DataFrame
# * List of dictionnaries
# * 2D numpy array
# * List of List
#
# The first dimension corresponds to observations
data_to_score = [
    {
        "fiscal_year_week": "2022_03"
        ,"fscl_wk_end_dt": "2021-10-23"
        ,"fiscalmonth": 1
        ,"fiscalmonth_5": False
        ,"fiscalweek": 3
        ,"new_welcome_home2": 0
        ,"offer_urgency_flag": False
        ,"offer_changeover_flag": False
        ,"offer_shadowside_flag": False
        ,"direct_live_product_price_per_point": 188.0
        ,"live_150_incentive_amount_min": 0.05472636815920398
        ,"live_150_incentive_amount_max": 0.05472636815920398
        ,"onsite_tours": 132
        ,"virtual_tours": 120
        ,"SoldOut_TourCount": 28
        ,"rofr_number_of_contracts_purchased_by_dvc": 36
        ,"rofr_price_per_point_average": 121
        ,"third_party_resale_price_per_point_avg": 154
        ,"member_calls_per_guide": 34.130434782608695
        ,"flash_sale_products_available": 4
        ,"flash_sale_products_live_new": 0
        ,"unique_members_contacted_sales_inmarket": 462.0
        ,"unique_members_contacted_sales_virtual": 966.0
        ,"unique_members_contacted_marketing": 50.0
        ,"net_contracts_finance_pct": 0.5342465753424658
        ,"dak_ind_avg": 0.8023255813953488
        ,"pct_members_any_borrow_1_to_2_years_before_arrival": 0.24408833300762164
        ,"pct_members_borrowed_one_year_in_past_5_years": 0.08071135430916553
        ,"new_product_month_after_launch": 0
        ,"new_product_on_sale_week": 0
        ,"booked_using_cash_and_dvc_points_count": 136
        ,"booked_using_only_dvc_points_count": 1779
        ,"booked_using_any_dvc_points_count": 1858
        ,"unique_dvc_email_clicks_sum": 3115
        ,"all_use_year_borrowing_amount_avg": 28.298249314490615
        ,"pct_arrivals_members_los_5_to_6": 0.23329515082092403
        ,"distinct_members_borrowing_count": 3066
        ,"average_daily_rate": 279.5342405877822
        ,"loans_with_5.01_to_10_years_remaining_count": 34977
        ,"financed_loans_closed": 105
        ,"consumer_confidence_interval": 111.6
        ,"intent_to_buy_home": 6.9
        ,"app_target_addon": 118.22352
        ,"dvc_welcome_home_more_than_1_unique_click_with_no_clicks_pct": -1.0
        ,"member_NWS_WDW": 1733965.0
        ,"member_outbound_calls_per_gscc": 0.0
        ,"era": "Ramp up"
        ,"era_15_year": 0
        ,"era_new_normal": 0
        ,"era_ramp_up": 1
        ,"total_tours_lag4": 0
        ,"net_contracts_total_lag_4_weeks": 0
        ,"net_contracts_total_lag_1_year": 0
        ,"average_daily_rate_lag_2_weeks": 289.2073110076904
        ,"average_daily_rate_lag_4_weeks": 0
        ,"virtual_addons_new_resort_with_existing_use_month_pct_lag_2_weeks": 0.24444444444444444
        ,"virtual_addons_new_resort_with_existing_use_month_pct_lag_4_weeks": 0
    }
    ,{
        "fiscal_year_week": "2022_13"
        ,"fscl_wk_end_dt": "2022-01-01"
        ,"fiscalmonth": 3
        ,"fiscalmonth_5": False
        ,"fiscalweek": 13
        ,"new_welcome_home2": 0
        ,"offer_urgency_flag": False
        ,"offer_changeover_flag": False
        ,"offer_shadowside_flag": False
        ,"direct_live_product_price_per_point": 187.0
        ,"live_150_incentive_amount_min": 0.029850746268656716
        ,"live_150_incentive_amount_max": 0.029850746268656716
        ,"onsite_tours": 142
        ,"virtual_tours": 77
        ,"SoldOut_TourCount": 49
        ,"rofr_number_of_contracts_purchased_by_dvc": 58
        ,"rofr_price_per_point_average": 127
        ,"third_party_resale_price_per_point_avg": 153
        ,"member_calls_per_guide": 29.75
        ,"flash_sale_products_available": 5
        ,"flash_sale_products_live_new": 0
        ,"unique_members_contacted_sales_inmarket": 603.0
        ,"unique_members_contacted_sales_virtual": 942.0
        ,"unique_members_contacted_marketing": 245.0
        ,"net_contracts_finance_pct": 0.5411764705882353
        ,"dak_ind_avg": 0.8875
        ,"pct_members_any_borrow_1_to_2_years_before_arrival": 0.2665751275009808
        ,"pct_members_borrowed_one_year_in_past_5_years": 0.07140054923499412
        ,"new_product_month_after_launch": 0
        ,"new_product_on_sale_week": 0
        ,"booked_using_cash_and_dvc_points_count": 152
        ,"booked_using_only_dvc_points_count": 1750
        ,"booked_using_any_dvc_points_count": 1822
        ,"unique_dvc_email_clicks_sum": 2453
        ,"all_use_year_borrowing_amount_avg": 27.90976496922216
        ,"pct_arrivals_members_los_5_to_6": 0.28848271305879764
        ,"distinct_members_borrowing_count": 4534
        ,"average_daily_rate": 376.1853799979615
        ,"loans_with_5.01_to_10_years_remaining_count": 34192
        ,"financed_loans_closed": 147
        ,"consumer_confidence_interval": 111.1
        ,"intent_to_buy_home": 7.0
        ,"app_target_addon": 137.60186
        ,"dvc_welcome_home_more_than_1_unique_click_with_no_clicks_pct": -1.0
        ,"member_NWS_WDW": 2287080.0
        ,"member_outbound_calls_per_gscc": 0.0
        ,"era": "Ramp up"
        ,"era_15_year": 0
        ,"era_new_normal": 0
        ,"era_ramp_up": 1
        ,"total_tours_lag4": 179
        ,"net_contracts_total_lag_4_weeks": 115.0
        ,"net_contracts_total_lag_1_year": 0
        ,"average_daily_rate_lag_2_weeks": 314.79468636178757
        ,"average_daily_rate_lag_4_weeks": 281.087318651225
        ,"virtual_addons_new_resort_with_existing_use_month_pct_lag_2_weeks": 0.1856060606060606
        ,"virtual_addons_new_resort_with_existing_use_month_pct_lag_4_weeks": 0.20816326530612245
    }
]


# For instance the following will output a numpy array containing the predictions for each
# observation

predict_result = model.predict(data_to_score)
print(" \nOutput of model.predict()\n")
pprint(predict_result)
