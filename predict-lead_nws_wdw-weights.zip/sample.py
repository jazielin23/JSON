import os
from pprint import pprint
from dataikuscoring import load_model


path_to_export = os.path.dirname(os.path.realpath(__file__))

# Load the model from current export path
model = load_model(path_to_export)

# The model provides a simple api similar to scikit-learn with:
# * model.predict to get scoring for a given input data
# * model.predict_proba to get probabilities in case of classification
#
# The accepted format for input data can be either:
# * pandas.DataFrame
# * List of dictionnaries
# * 2D numpy array
# * List of List
#
# The first dimension corresponds to observations
data_to_score = [
    {
        "model": "WDW_Lead"
        ,"weekending": "2021-11-27"
        ,"weekending_date": "2021-11-27T00:00:00.000Z"
        ,"lead_nws_wdw": 2042018.0
        ,"lead_tours_onsite_wdw": 114
        ,"lead_netcontracts_wdw": 42.99995
        ,"lead_ppp_wdw": 201.223689397
        ,"spring_offer": 0
        ,"summer_offer": 0
        ,"winter_offer": 0
        ,"fall_offer": 0
        ,"holiday_offer": 0
        ,"last_2_weeks_of_offer": 0
        ,"tour_regime_indicator": 0
        ,"lead_app_wdw": 238.6952
    }
    ,{
        "model": "WDW_Lead"
        ,"weekending": "2021-12-04"
        ,"weekending_date": "2021-12-04T00:00:00.000Z"
        ,"lead_nws_wdw": 2875929.0
        ,"lead_tours_onsite_wdw": 138
        ,"lead_netcontracts_wdw": 58.99996
        ,"lead_ppp_wdw": 203.836487349
        ,"spring_offer": 0
        ,"summer_offer": 0
        ,"winter_offer": 0
        ,"fall_offer": 0
        ,"holiday_offer": 0
        ,"last_2_weeks_of_offer": 0
        ,"tour_regime_indicator": 0
        ,"lead_app_wdw": 238.41268
    }
]


# For instance the following will output a numpy array containing the predictions for each
# observation

predict_result = model.predict(data_to_score)
print(" \nOutput of model.predict()\n")
pprint(predict_result)
