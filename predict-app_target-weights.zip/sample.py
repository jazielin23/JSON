import os
from pprint import pprint
from dataikuscoring import load_model


path_to_export = os.path.dirname(os.path.realpath(__file__))

# Load the model from current export path
model = load_model(path_to_export)

# The model provides a simple api similar to scikit-learn with:
# * model.predict to get scoring for a given input data
# * model.predict_proba to get probabilities in case of classification
#
# The accepted format for input data can be either:
# * pandas.DataFrame
# * List of dictionnaries
# * 2D numpy array
# * List of List
#
# The first dimension corresponds to observations
data_to_score = [
    {
        "weekending": "2021-10-30T00:00:00.000Z"
        ,"max_250_inc_ppt": 6.467661691542289
        ,"points_season_2": False
        ,"adr": 269.19354134122597
        ,"arrivals_leads_los7_pcent": 0.11731674002124753
        ,"arrivals_leads_los5to6_pcent": 0.27879799666110183
        ,"leads_repeat_within_1year_pcent_arrivals": 0.03295845997973657
        ,"onsite_deluxeorvilla_pcent": 0.44551193244106063
        ,"onsite_oneadult_in_hh_pcent": 0.07572070498379693
        ,"onsite_somekids_in_hh_pcent": 0.213127492199641
    }
    ,{
        "weekending": "2021-11-06T00:00:00.000Z"
        ,"max_250_inc_ppt": 6.467661691542289
        ,"points_season_2": False
        ,"adr": 255.6050250823154
        ,"arrivals_leads_los7_pcent": 0.1350305195771922
        ,"arrivals_leads_los5to6_pcent": 0.2639571237159446
        ,"leads_repeat_within_1year_pcent_arrivals": 0.03130886065803711
        ,"onsite_deluxeorvilla_pcent": 0.4311855423987777
        ,"onsite_oneadult_in_hh_pcent": 0.07485437356760886
        ,"onsite_somekids_in_hh_pcent": 0.20663435828877005
    }
]


# For instance the following will output a numpy array containing the predictions for each
# observation

predict_result = model.predict(data_to_score)
print(" \nOutput of model.predict()\n")
pprint(predict_result)
