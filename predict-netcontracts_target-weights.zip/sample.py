import os
from pprint import pprint
from dataikuscoring import load_model


path_to_export = os.path.dirname(os.path.realpath(__file__))

# Load the model from current export path
model = load_model(path_to_export)

# The model provides a simple api similar to scikit-learn with:
# * model.predict to get scoring for a given input data
# * model.predict_proba to get probabilities in case of classification
#
# The accepted format for input data can be either:
# * pandas.DataFrame
# * List of dictionnaries
# * 2D numpy array
# * List of List
#
# The first dimension corresponds to observations
data_to_score = [
    {
        "weekending": ""
        ,"PreCovid": "PostCovidRamp"
        ,"fiscalquarter": 2
        ,"Offer_flag": "Offer_Normal_Week"
        ,"percent_days_worked_cruise": 0.01216
        ,"avg_laborhours_guide": 41
        ,"onsite_tours": 129
        ,"lead_pcent_nights": 0.14781123165145102
        ,"live_product_count": 2
        ,"max_250_inc_ppt": 8.695652173913043
        ,"min_250_inc_ppt": 8.695652173913043
    }
    ,{
        "weekending": ""
        ,"PreCovid": "PostCovidRamp"
        ,"fiscalquarter": 3
        ,"Offer_flag": "Offer_Normal_Week"
        ,"percent_days_worked_cruise": 0.04464
        ,"avg_laborhours_guide": 37
        ,"onsite_tours": 159
        ,"lead_pcent_nights": 0.14031203197896802
        ,"live_product_count": 2
        ,"max_250_inc_ppt": 6.310679611650485
        ,"min_250_inc_ppt": 2.898550724637681
    }
]


# For instance the following will output a numpy array containing the predictions for each
# observation

predict_result = model.predict(data_to_score)
print(" \nOutput of model.predict()\n")
pprint(predict_result)
